To use tuProlog from .NET you must reference at least 2p.exe and IKVM.OpenJDK.Core.dll (lib directory of this distribution) in your project.
Then insert "using alice.tuprolog;" in your code to use the tuProlog APIs.

Before running the examples in this folder, open the OOLibrary solution and build it with target Release, this step will generate the files OOLibrary.dll and Conventions.dll that are required by the examples.
