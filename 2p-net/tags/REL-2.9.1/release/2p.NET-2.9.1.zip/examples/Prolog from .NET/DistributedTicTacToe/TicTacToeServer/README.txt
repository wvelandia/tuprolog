The file tuprolog.jar is present here only for convenience, because
it is referenced by the example.
The complete Java distribution of tuProlog can be found at http://tuprolog.unibo.it.