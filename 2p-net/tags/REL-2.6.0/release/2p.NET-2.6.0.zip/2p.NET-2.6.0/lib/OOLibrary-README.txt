The OOLibrary.dll inserted here is not copied from another location via svn:externals.
This is just a "shortcut" for an easier use of the library but in the future the DLL
should be present under the REL-x.x.x/OOLibrary and it should be copied in this location
as external reference. 
The same consideration is true even for the file Conventions.dll.